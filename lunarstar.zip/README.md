# 星月紀資源包

此資源包為多方資源組合修改而來，其中使用之資源部分為其他作者之所有權物。

非經星月紀伺服器官方團隊許可，不得複製、修改、公開發送。

> 星月紀伺服器
> 官方網站: [https://lunarstar.axolotldev.me](https://lunarstar.axolotldev.me)
> 伺服器IP: mc.lunarstar.axolotldev.me